/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author elitz
 */
public class OrganizationTest {
    
    public OrganizationTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of addOrganization method, of class Organization.
     */
    @Test
    public void testAddOrganization() {
        System.out.println("addOrganization");
        Organization instance = new Organization("Red Cross", "205 E W Beaver Ave State College, PA 16801", "support@redcrosstraining.come", "18007332767", "non-profit");
        instance.addOrganization();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of searchOrganization method, of class Organization.
     */
    @Test
    public void testSearchOrganization() {
        System.out.println("searchOrganization");
        Organization instance = new Organization("Red Cross", "205 E W Beaver Ave State College, PA 16801", "support@redcrosstraining.come", "18007332767", "non-profit");
        Organization expResult = new Organization("Red Cross", "205 E W Beaver Ave State College, PA 16801", "support@redcrosstraining.come", "18007332767", "non-profit");
        Organization result = instance.searchOrganization();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getName method, of class Organization.
     */
    @Test
    public void testGetName() {
        System.out.println("getName");
        Organization instance = new Organization ("Red Cross", "205 E W Beaver Ave State College, PA 16801", "support@redcrosstraining.come", "18007332767", "non-profit");
        String expResult = "";
        String result = instance.getName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
