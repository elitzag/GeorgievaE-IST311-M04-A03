/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author elitz
 */
import java.util.Scanner;
import java.util.ArrayList;
public class Person {
    
    String personName;
    int personAge;
    String personAddress;
    String personEmail;
    String personTelephone;
    
    ArrayList<Person> list = new ArrayList<Person>();
    
    public Person(String personName, int personAge,
            String personAddress, String personEmail,
            String personTelephone)
    {
        this.personName=personName;
        this.personAge= personAge;
        this.personAddress=personAddress;
        this.personEmail=personEmail;
        this.personTelephone=personTelephone;
    }
    
    public void addPerson()
    {
        Scanner in = new Scanner(System.in);
        
        System.out.println("Enter your name.");
        String name = in.nextLine();
        
        System.out.println("Enter your age.");
        int age = in.nextInt();
        
        System.out.println("Enter your address.");
        String address = in.nextLine();
        
        System.out.println("Enter your email.");
        String email = in.nextLine();
        
        System.out.println("Enter your telephone number.");
        String telephone = in.nextLine();
        
        list.add(new Person(name, age, address, email, telephone));
        
    }
    
    public void removePerson()
    {
        Scanner in = new Scanner(System.in);
        
        System.out.println("Enter name of person to remove.");
        String name = in.nextLine();
        
        for (Person member : list)
        {
            if(member.getName() == name)
            {
                list.remove(member);
            }
        }
    }
    
    public String getName()
    {
        return personName;
    }
    
}
