/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author elitz
 */
import java.util.Scanner;
import java.util.ArrayList;
public class Organization {
    
    String orgName;
    String orgAddress;
    String orgEmail;
    String orgTelephone;
    String orgType;
    
    ArrayList<Organization> list = new ArrayList<Organization>();
    
    public Organization(String orgName,
            String orgAddress, String orgEmail,
            String orgTelephone, String orgType)
    {
        this.orgName=orgName;
        this.orgAddress=orgAddress;
        this.orgEmail=orgEmail;
        this.orgTelephone=orgTelephone;
        this.orgType = orgType;
    }
    
    public void addOrganization()
    {
        Scanner in = new Scanner(System.in);
        
        System.out.println("Enter the organization's name.");
        String name = in.nextLine();

        System.out.println("Enter the organization's address.");
        String address = in.nextLine();
        
        System.out.println("Enter the organization's email.");
        String email = in.nextLine();
        
        System.out.println("Enter the organization's telephone number.");
        String telephone = in.nextLine();
        
        System.out.println("Enter the organization's type.");
        String type = in.nextLine();
        
        list.add(new Organization(name, address, email, telephone, type));
        
    }
    
    public Organization searchOrganization()
    {
        Scanner in = new Scanner(System.in);
        
        System.out.println("Enter the name of the organization.");
        String name = in.nextLine();
        
        for (Organization org : list)
        {
            if(org.getName() == name)
            {
                return org;
            }
        }
        
        return null;
    }
    
    public String getName()
    {
        return orgName;
    }
    
}
